document.addEventListener("DOMContentLoaded", () => {
    const apiUrl = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false';
    const cardContainer = document.getElementById('card-container');
    const loader = document.getElementById('loader');

    // Show loader
    loader.style.display = 'flex';

    fetch(apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Hide loader
            loader.style.display = 'none';
            cardContainer.style.display = 'flex'; // Show card container

            data.forEach((item, index) => {
                const card = document.createElement('div');
                card.className = 'card';
                card.innerHTML = `
                    <img src="${item.image}" alt="${item.name}">
                    <h3>${item.name} (${item.symbol.toUpperCase()})</h3>
                    <p>Current Price: $${item.current_price.toLocaleString()}</p>
                    <p>Market Cap: $${item.market_cap.toLocaleString()}</p>
                    <p>24h High: $${item.high_24h.toLocaleString()}</p>
                    <p>24h Low: $${item.low_24h.toLocaleString()}</p>
                `;
                cardContainer.appendChild(card);

                // Adjusting card container to display 4 in the first row and the rest in the next row
                if (index === 3) {
                    cardContainer.appendChild(document.createElement('div')).style.flexBasis = '100%'; // Create a new row
                }
            });
        })
        .catch(error => {
            // Hide loader and log the error
            loader.style.display = 'none';
            console.error('Error fetching data:', error);
        });
});
